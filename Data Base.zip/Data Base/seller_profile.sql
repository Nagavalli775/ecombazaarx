CREATE TABLE seller_profile (
    seller_id BIGINT UNSIGNED PRIMARY KEY,
    business_name VARCHAR(150) NOT NULL,
    gst_number VARCHAR(20) UNIQUE,
    business_address VARCHAR(255) NOT NULL,

    CONSTRAINT fk_seller_profile_user
        FOREIGN KEY (seller_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
