CREATE TABLE user_profile (
    user_id BIGINT UNSIGNED PRIMARY KEY,
    birthdate DATE,
    gender ENUM('MALE','FEMALE','OTHER'),
    default_city VARCHAR(80),

    CONSTRAINT fk_user_profile_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
