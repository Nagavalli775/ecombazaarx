CREATE TABLE admin_profile (
    admin_id BIGINT UNSIGNED PRIMARY KEY,
    employee_code VARCHAR(20) UNIQUE,
    access_level ENUM('LOW','MEDIUM','HIGH') NOT NULL DEFAULT 'LOW',

    CONSTRAINT fk_admin_profile_user
        FOREIGN KEY (admin_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
